export const titles = [

    {
        item: 'Home'
    },
    {
        item: 'About us'
    },
    {
        item: 'Contact'
    },
    {
        item: 'What we make'
    }
]

