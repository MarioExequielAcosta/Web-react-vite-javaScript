export const currentInformation = {

    dolar: "127.23",
    dolarParalelo: "212.2",
    riesgoPais: "2.124"
}