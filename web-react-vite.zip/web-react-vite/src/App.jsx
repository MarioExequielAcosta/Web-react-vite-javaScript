import React from 'react'
import PublicRoutes from './Routes/PublicRoutes'
import './App.css'

const App = () => {
 

    return (
        <div className='App'>
            <PublicRoutes />
        </div>
    )
}

export default App




 