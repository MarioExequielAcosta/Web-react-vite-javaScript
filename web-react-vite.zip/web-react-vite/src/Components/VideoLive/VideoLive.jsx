import React from 'react'
import PropTypes from 'prop-types'

export const VideoLive = props => {
    return (
        <div>
            <iframe width="420" height="315"
                src="https://fb.gg/v/dLC_t6Km8F/">  
            </iframe>
        </div>
    )
}

VideoLive.propTypes = {}

