import React from 'react'
import PropTypes from 'prop-types'

export const Register = props => {
  return (
    <div>Register</div>
  )
}

Register.propTypes = {}
 