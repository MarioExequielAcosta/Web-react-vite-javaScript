import React from 'react'
import PropTypes from 'prop-types'
import './LastsNewsButton.css'

export const LastsNewsButton = props => {
  return (
    <span className='LastsNewsButton'>Últimas noticias</span>
  )
}

LastsNewsButton.propTypes = {}

