import React from 'react'
import PropTypes from 'prop-types'
import { Link } from 'react-router-dom'
import './CardHome.css'


export const CardHome = ({ id, title, paragraph, image }) => {
    const route = `/${id} `
    return (


        <div className='card-home'>
            <Link to={route} className='link-card-home'>
                <img className='image-card-home' src={image} alt={title} />
                <div className='main-tittle-card-home'>
                    <span className='title-card-home'>{title}</span>
                </div>
                {/* <span className='paragraph-card-home'>{paragraph}</span> */}
            </Link>
        </div >

    )
}

CardHome.propTypes = {
    id: PropTypes.number,
    title: PropTypes.string,
    paragraph: PropTypes.string
}

