import React from 'react'
import PropTypes from 'prop-types'

export const Login = props => {
  return (
    <div>Login</div>
  )
}

Login.propTypes = {}

 