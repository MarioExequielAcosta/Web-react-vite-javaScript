import React from 'react'
import PropTypes from 'prop-types'

export const NotFound = props => {
  return (
    <div>NotFound</div>
  )
}

NotFound.propTypes = {}

 