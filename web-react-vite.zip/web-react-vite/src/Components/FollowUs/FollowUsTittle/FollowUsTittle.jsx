import React from 'react'
import PropTypes from 'prop-types'
import './FollowUsTittle.css'

export const FollowUsTittle = props => {
  return (
    <span className='FollowUsTittle'>Follow us</span>
  )
}

FollowUsTittle.propTypes = {}

 