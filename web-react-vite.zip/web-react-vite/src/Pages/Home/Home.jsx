import React from 'react'
import './Home.css'
import { Banner } from '../../Components/Banner/Banner.jsx'
import { MapCardHome } from '../../Components/MapCardHome/MapCardHome'
import { ContainerCards } from '../../Components/ContainerCards/ContainerCards'
import { CardMainHome } from '../../Components/CardMainHome/CardMainHome'
import { CardMainHomeObj } from '../../Utils/Card.utils'
import { FollowUs } from '../../Components/FollowUs/FollowUs'
import { LastsNewsButton } from '../../Components/LastsNewsButton/LastsNewsButton'
import { Publicity } from '../../Components/Publicity/Publicity'
import MapSmallCard from '../../Components/MapSmallCard/MapSmallCard'
import { arrayCardsHome, lastNewsArray, arraySmallCards } from '../../Utils/Card.utils'
import { ContainerCardsMain } from '../../Components/ContaineCardMain/ContainerCardMain'
import { Pagination } from '../../Components/Pagination/Pagination'
import { PublicityBanner } from '../../Components/PublicityBanner/PublicityBanner'
import { Slider } from '../../Components/Slider/Slider'
// import { VideoLive } from '../../Components/VideoLive/VideoLive'


export const Home = () => {
    return (
        <div className='home'>
            <div className='home-section'>
                <Banner />

                <div className='home-container'>
                    <div className='publicidad-banner'>
                        <PublicityBanner />
                    </div>
                    <div className='container-home-2'>
                        <ContainerCardsMain title={'Noticias destacadas'} arrayCard={arrayCardsHome} />
                        <FollowUs />
                    </div>
                </div>

            </div>
            <div className='home-container-main'>
                <Slider home={true} arrayImage={arraySmallCards} />
                <div className='home-container-container'>
                    <CardMainHome title={CardMainHomeObj.title} paragraph={CardMainHomeObj.paragraph} id={CardMainHomeObj.id} image={CardMainHomeObj.image} />
                    <CardMainHome title={CardMainHomeObj.title} paragraph={CardMainHomeObj.paragraph} id={CardMainHomeObj.id} image={CardMainHomeObj.image} />
                </div>
            </div>

            <div>
                {/* <MapSmallCard/> */}

            </div>
            <div className='home-container-pagination'>
                <ContainerCards title={'Ultimas noticias'} arrayCard={lastNewsArray} />
                <Pagination />
            </div>
            {/* <div>
                <VideoLive></VideoLive>
            </div> */}
        </div>
    )
}


//Crear mail de Cooperar